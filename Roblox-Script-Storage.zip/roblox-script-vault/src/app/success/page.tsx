'use client';

import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';
import { Suspense } from 'react';

// Component that uses useSearchParams wrapped in Suspense
function SuccessContent() {
  const searchParams = useSearchParams();
  const key = searchParams.get('key');

  return (
    <div className="flex flex-col items-center justify-center space-y-6 text-center">
      <div className="h-24 w-24 rounded-full bg-green-100 flex items-center justify-center">
        <CheckCircle className="h-12 w-12 text-green-600" />
      </div>

      <h1 className="text-3xl font-bold">Script Saved Successfully!</h1>

      <p className="text-lg text-muted-foreground max-w-md">
        Your Roblox script has been saved successfully. Use the key below to retrieve it later.
      </p>

      {key && (
        <div className="p-4 bg-muted rounded-md font-mono text-xl max-w-xs w-full overflow-auto">
          {key}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-4 pt-4">
        <Link href="/lookup">
          <Button variant="outline">Retrieve a Script</Button>
        </Link>

        <Link href="/submit">
          <Button variant="outline">Submit Another Script</Button>
        </Link>

        <Link href="/">
          <Button>Back to Home</Button>
        </Link>
      </div>
    </div>
  );
}

// Main success page component with Suspense
export default function SuccessPage() {
  return (
    <div className="container max-w-3xl mx-auto py-10 px-4">
      <Suspense fallback={
        <div className="flex flex-col items-center justify-center space-y-6 text-center">
          <div className="h-24 w-24 rounded-full bg-muted flex items-center justify-center animate-pulse">
          </div>
          <h1 className="text-3xl font-bold">Loading...</h1>
        </div>
      }>
        <SuccessContent />
      </Suspense>
    </div>
  );
}
