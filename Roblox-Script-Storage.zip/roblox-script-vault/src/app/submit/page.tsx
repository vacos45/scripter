'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';
import { SubmitFormValues } from '@/types/script';

// UI components
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

// Schema for form validation
const formSchema = z.object({
  key: z
    .string()
    .min(3, { message: 'Key must be at least 3 characters long' })
    .max(50, { message: 'Key must be less than 50 characters' })
    .regex(/^[a-zA-Z0-9-_]+$/, {
      message: 'Key can only contain letters, numbers, hyphens, and underscores',
    }),
  script: z
    .string()
    .min(10, { message: 'Script must be at least 10 characters long' })
    .max(100000, { message: 'Script is too large (max 100KB)' }),
});

export default function SubmitPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();

  // Initialize form
  const form = useForm<SubmitFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      key: '',
      script: '',
    },
  });

  // Form submission handler
  async function onSubmit(values: SubmitFormValues) {
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/scripts/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to save script');
      }

      toast.success('Script saved successfully!');
      form.reset();
      router.push(`/success?key=${encodeURIComponent(values.key)}`);
    } catch (error) {
      console.error('Error saving script:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to save script');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="container max-w-3xl mx-auto py-10 px-4">
      <div className="mb-8">
        <Link href="/" className="text-primary hover:underline flex items-center gap-1">
          ← Back to Home
        </Link>
        <h1 className="text-3xl font-bold mt-4">Submit Roblox Script</h1>
        <p className="text-muted-foreground mt-2">
          Store your Roblox script with a unique key for easy retrieval later.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="key"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Unique Key</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Enter a unique key (e.g., my-script-123)"
                    {...field}
                    autoComplete="off"
                  />
                </FormControl>
                <FormDescription>
                  This key will be used to retrieve your script later.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="script"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Roblox Script</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Paste your Roblox script here"
                    className="font-mono h-64 resize-y"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Your script will be stored securely and can be retrieved using your key.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Script'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
