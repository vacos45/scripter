import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function Home() {
  return (
    <div className="container max-w-4xl mx-auto py-12 px-4">
      <div className="flex flex-col items-center space-y-8">
        <h1 className="text-4xl font-bold text-center">Roblox Script Vault</h1>
        <p className="text-xl text-center text-muted-foreground">
          Store and retrieve your Roblox scripts securely with a unique key
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-lg">
          <Link href="/submit" className="w-full">
            <Button className="w-full h-24 text-lg" size="lg">
              Submit a Script
            </Button>
          </Link>
          <Link href="/lookup" className="w-full">
            <Button className="w-full h-24 text-lg" variant="outline" size="lg">
              Retrieve a Script
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
