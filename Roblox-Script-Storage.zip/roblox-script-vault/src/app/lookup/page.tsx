'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';
import { toast } from 'sonner';
import { LookupFormValues } from '@/types/script';

// UI components
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

// Schema for lookup form validation
const lookupSchema = z.object({
  key: z.string().min(1, { message: 'Please enter a key' }),
});

export default function LookupPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [script, setScript] = useState<string | null>(null);

  // Initialize form
  const form = useForm<LookupFormValues>({
    resolver: zodResolver(lookupSchema),
    defaultValues: {
      key: '',
    },
  });

  // Form submission handler
  async function onSubmit(values: LookupFormValues) {
    setIsLoading(true);
    setScript(null);

    try {
      const response = await fetch(`/api/scripts/get?key=${encodeURIComponent(values.key)}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Script not found');
      }

      setScript(data.script);
      toast.success('Script retrieved successfully!');
    } catch (error) {
      console.error('Error retrieving script:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to retrieve script');
    } finally {
      setIsLoading(false);
    }
  }

  const copyToClipboard = () => {
    if (!script) return;

    navigator.clipboard.writeText(script)
      .then(() => toast.success('Script copied to clipboard'))
      .catch(() => toast.error('Failed to copy script'));
  };

  return (
    <div className="container max-w-3xl mx-auto py-10 px-4">
      <div className="mb-8">
        <Link href="/" className="text-primary hover:underline flex items-center gap-1">
          ← Back to Home
        </Link>
        <h1 className="text-3xl font-bold mt-4">Retrieve Roblox Script</h1>
        <p className="text-muted-foreground mt-2">
          Enter your unique key to retrieve your previously saved Roblox script.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="key"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Script Key</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Enter your script key"
                    {...field}
                    autoComplete="off"
                  />
                </FormControl>
                <FormDescription>
                  Enter the unique key you used when saving your script.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Retrieving...' : 'Retrieve Script'}
            </Button>
          </div>
        </form>
      </Form>

      {script && (
        <div className="mt-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Your Script</h2>
            <Button variant="outline" size="sm" onClick={copyToClipboard}>
              Copy to Clipboard
            </Button>
          </div>

          <div className="relative rounded-md border">
            <Textarea
              className="font-mono p-4 h-80 resize-none bg-muted/50"
              value={script}
              readOnly
            />
          </div>
        </div>
      )}
    </div>
  );
}
