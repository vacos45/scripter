import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';
import { ScriptsData } from '@/types/script';

// Data storage location in the temporary filesystem
const STORAGE_DIR = '/tmp';
const SCRIPTS_FILE = path.join(STORAGE_DIR, 'roblox-scripts.json');

export async function GET(request: NextRequest) {
  try {
    // Get the key from the request URL
    const url = new URL(request.url);
    const key = url.searchParams.get('key');

    if (!key) {
      return NextResponse.json(
        { success: false, message: 'Script key is required' },
        { status: 400 }
      );
    }

    // Check if the scripts file exists
    try {
      await fs.access(SCRIPTS_FILE);
    } catch (error) {
      return NextResponse.json(
        { success: false, message: 'Script not found' },
        { status: 404 }
      );
    }

    // Read the scripts file
    const fileData = await fs.readFile(SCRIPTS_FILE, 'utf-8');
    const scriptsData = JSON.parse(fileData) as ScriptsData;

    // Check if the key exists in the data
    const scriptEntry = scriptsData[key];
    if (!scriptEntry) {
      return NextResponse.json(
        { success: false, message: 'Script not found' },
        { status: 404 }
      );
    }

    // Return the script
    return NextResponse.json({
      success: true,
      script: scriptEntry.script,
      createdAt: scriptEntry.createdAt
    });
  } catch (error) {
    console.error('Error retrieving script:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to retrieve script' },
      { status: 500 }
    );
  }
}
