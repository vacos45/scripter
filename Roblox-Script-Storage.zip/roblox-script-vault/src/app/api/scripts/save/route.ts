import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';
import { z } from 'zod';
import { ScriptsData } from '@/types/script';

// Data storage location in the temporary filesystem
const STORAGE_DIR = '/tmp';
const SCRIPTS_FILE = path.join(STORAGE_DIR, 'roblox-scripts.json');

// Schema for validation
const scriptSchema = z.object({
  key: z
    .string()
    .min(3)
    .max(50)
    .regex(/^[a-zA-Z0-9-_]+$/),
  script: z
    .string()
    .min(10)
    .max(100000),
});

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();
    const result = scriptSchema.safeParse(body);

    if (!result.success) {
      return NextResponse.json(
        { success: false, message: 'Invalid input data' },
        { status: 400 }
      );
    }

    const { key, script } = result.data;

    // Ensure storage directory exists
    try {
      await fs.mkdir(STORAGE_DIR, { recursive: true });
    } catch (error) {
      console.error('Error creating storage directory:', error);
    }

    // Read existing data or create new data store
    let scriptsData: ScriptsData = {};

    try {
      const fileData = await fs.readFile(SCRIPTS_FILE, 'utf-8');
      scriptsData = JSON.parse(fileData) as ScriptsData;
    } catch (error) {
      // File doesn't exist or can't be read, starting with empty object
      console.info('Creating new scripts storage file');
    }

    // Check if key already exists
    if (scriptsData[key]) {
      return NextResponse.json(
        { success: false, message: 'A script with this key already exists' },
        { status: 409 }
      );
    }

    // Add new script
    scriptsData[key] = {
      script,
      createdAt: new Date().toISOString(),
    };

    // Write data back to file
    await fs.writeFile(SCRIPTS_FILE, JSON.stringify(scriptsData, null, 2), 'utf-8');

    return NextResponse.json({
      success: true,
      message: 'Script saved successfully'
    });
  } catch (error) {
    console.error('Error saving script:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to save script' },
      { status: 500 }
    );
  }
}
