import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

// Path to our storage file in the temporary filesystem
const SCRIPTS_FILE_PATH = path.join('/tmp', 'scripts.json');

// Interface for our script data
interface ScriptData {
  key: string;
  script: string;
  createdAt: string;
}

// Function to get the current scripts data
async function getScriptsData(): Promise<Record<string, ScriptData>> {
  try {
    // Check if the file exists
    await fs.access(SCRIPTS_FILE_PATH);

    // Read the file
    const data = await fs.readFile(SCRIPTS_FILE_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    // If file doesn't exist or there's an error, return an empty object
    return {};
  }
}

// Function to save scripts data
async function saveScriptsData(data: Record<string, ScriptData>): Promise<void> {
  try {
    // Ensure directory exists
    await fs.mkdir(path.dirname(SCRIPTS_FILE_PATH), { recursive: true });

    // Write to the file
    await fs.writeFile(SCRIPTS_FILE_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error saving scripts data:', error);
    throw new Error('Failed to save script');
  }
}

export async function POST(request: NextRequest) {
  try {
    // Parse the request body
    const { key, script } = await request.json();

    // Validate input
    if (!key || typeof key !== 'string') {
      return NextResponse.json(
        { error: 'Key is required and must be a string' },
        { status: 400 }
      );
    }

    if (!script || typeof script !== 'string') {
      return NextResponse.json(
        { error: 'Script is required and must be a string' },
        { status: 400 }
      );
    }

    // Get current data
    const scriptsData = await getScriptsData();

    // Check if key already exists
    if (scriptsData[key]) {
      return NextResponse.json(
        { error: 'Key already exists. Please use a different key.' },
        { status: 409 }
      );
    }

    // Add new script data
    scriptsData[key] = {
      key,
      script,
      createdAt: new Date().toISOString()
    };

    // Save updated data
    await saveScriptsData(scriptsData);

    return NextResponse.json({ success: true, key }, { status: 201 });
  } catch (error) {
    console.error('Error in saveScript API:', error);
    return NextResponse.json(
      { error: 'Failed to save script' },
      { status: 500 }
    );
  }
}
