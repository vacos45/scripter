"use client";

import { useState, useEffect } from 'react';

interface ClientBodyProps {
  children: React.ReactNode;
}

export default function ClientBody({ children }: ClientBodyProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // This runs only on the client after hydration
    document.body.className = "antialiased";
  }, []);

  if (!mounted) {
    return null;
  }

  return (
    <body className="antialiased" suppressHydrationWarning>
      {children}
    </body>
  );
}
