export interface ScriptEntry {
  script: string;
  createdAt: string;
}

export interface ScriptsData {
  [key: string]: ScriptEntry;
}

export interface SubmitFormValues {
  key: string;
  script: string;
}

export interface LookupFormValues {
  key: string;
}

export interface ApiResponse {
  success: boolean;
  message: string;
  script?: string;
  createdAt?: string;
}
